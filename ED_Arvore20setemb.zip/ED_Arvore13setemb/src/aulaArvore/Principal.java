package aulaArvore;

public class Principal {
	
	
	public static void main ( String args[]) {
		No raiz = new No(10);
		
		No num5 = new No(5);
		No num30 = new No(30);
		No num2 = new No(2);
		raiz.setEsq(num30);
		raiz.setDir(num5);
		num30.setDir(num2);
		
		//raiz.buscarValor(raiz, 30, 0);
		
		raiz.removerNoFolha(raiz, 2);
		
		System.out.println("Pré-Ordem: ");
		raiz.preOrdem(raiz);
		System.out.println("\nEm-Ordem: ");
		raiz.emOrdem(raiz);
		System.out.println("\nPÓS-ORDEM: ");
		raiz.posOrdem(raiz);
		
	}

}

/*
 * 
 * INSERÇÓES QUE EU FIZ EM AULA
package aulaArvore;

public class Principal {
	
	public static void main (String args[]) {

	No raiz = new No(1);
	No num2 = new No(2);
	No num5 = new No(5);
	No num6 = new No(6);
	No num9 = new No(9);
	No num10 = new No(10);
	No num12 = new No(12);
	No num4 = new No(4);
	No num3 = new No(3);
	No num7 = new No(7);
	No num8 = new No(8);
	No num11 = new No(11);
	
	raiz.setEsq(num2);
	raiz.setDir(num4);
	raiz.setMeio(num3);
	
	//nessa arvóre, essa linha abaixo é como se o 2 fosse filho do 30
	num2.setDir(num6);
	num2.setEsq(num5);
	num5.setDir(num9);
	num5.setDir(num10);
	
	//nessa árvore, o essa linha abaixo é como se o 7, 8 11 e 12 fossem filhos do 4
	num4.setEsq(num7);
	num4.setDir(num8);
	num7.setEsq(num11);
	num7.setDir(num12);
	
	//raiz.preOrdem(raiz);
	raiz.emOrdem(raiz);
	
}
}
*/	