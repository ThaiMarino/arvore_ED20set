package aulaArvore;

public class No {
	
	private int valor;
	private No esq;
	private No dir;
	private No meio;
	
	//criacao dos vetores em que o nó apontará
	No (int valor){
		this.valor = valor;
		this.esq = null;
		this.dir = null;
		this.meio = null;
	}
	
	//Método para filtrar e inserir nós
	public void inserirNo (No raiz, No novoNo) {
		if (raiz == null) {
			raiz = novoNo;
		} else {
			if (novoNo.getValor() < raiz.getValor()) { // vai para esquerda
				if (raiz.getEsq() == null) {
					raiz.setEsq(novoNo);
				}else {
					inserirNo(raiz.getEsq(), novoNo);
				}
			}else if (novoNo.getValor() > raiz.getValor()) {
				if (raiz.getDir() == null) {
					raiz.setDir(novoNo);
				}else {
					inserirNo(raiz.getDir(), novoNo);
				} 
			} else  {
					System.out.println("Números iguais.");
			}
		}
		}
	
	/*
	 * buscarValor
	1. Verificar se o número pesquisado está no nó raiz.
	2. Caso não esteja, verificar se o número pesquisado é menorque o nó raiz.
	a) Se sim, percorrer o nó esquerdo repetindo o passo 1.
	b) Senão, percorrer o nó direito repetindo o passo 1.
	 */
	
	public void buscarValor(No raiz, int valor, int contador) {
		if (raiz == null) {
			if(contador == 0) {
				System.out.println("Árvore vazia.");
			}else {
				System.out.println("Valor NÃO encontrado.");
			}
		}else if(raiz.getValor() == valor) {
			System.out.println("Valor encontrado no : + contador");
		}else if (valor < raiz.getValor()) {
			buscarValor(raiz.getEsq(), valor, ++contador);
		}else {
			buscarValor(raiz.getDir(), valor, ++contador);
		}
	}
	
	
	/*
	 * excluiNo
	 * Monte o algoritmo para realizar a
	remoção quando o nó é folha
	-recebe o valor a ser excluido
	-checa se existem nos à direita do valor
	-checa se existem nos à esquerda do valor
	-se não tiver nós nas direções, ele exclui
	 */
	public void removerNoFolha(No raiz, int valor) {
		if (raiz == null ) {
			System.out.println("Árvore vazia.");
		}else if(valor == raiz.getValor()) {
			if (raiz.getEsq() == null && raiz.getDir() == null) {
				System.out.println("Removeu");
				raiz = null;
			}else {
				System.out.println("Tem filhos.");
			}
		}else if(valor < raiz.getValor()) {
			removerNoFolha(raiz.getEsq(), valor);
		}else {
			removerNoFolha(raiz.getDir(), valor);
		}
	}
	
	
	@Override
	public String toString() {
		return " " + valor + " ";
	}
	

	public void setEsq(No esq) {
		this.esq = esq;
	}

	public void setDir(No dir) {
		this.dir = dir;
	}
	
	public void setMeio(No meio) {
		this.meio = meio;
	}
	
	public No getEsq() {
		return this.esq;
	}
	
	public No getDir() {
		return this.dir;
	}
	
	public int getValor() {
		return this.valor;
	}
	
	
	public void preOrdem(No raiz) {
		//1 passo: imprimir raiz
		//Esquerda
		//Direita
		
		
		if (raiz != null) {
			
		System.out.print(raiz + " ");
		preOrdem(raiz.getEsq());
		preOrdem(raiz.getDir());
		
		
	}
	}
	
	public void emOrdem(No raiz) {
		//1 passo: imprimir raiz
		//direita
		//esquerda
		
		if (raiz != null) {
		
		emOrdem(raiz.getEsq());
		System.out.print(raiz + " ");
		emOrdem(raiz.getDir());
	}
	}
	
	public void posOrdem(No raiz) {
		//1 passo: imprimir raiz
		//direita
		//esquerda
		
		if (raiz != null) {
		
		posOrdem(raiz.getDir());
		posOrdem(raiz.getEsq());
		System.out.print(raiz + " ");
	}
	}
}


